#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <sys/wait.h>
#include <errno.h>

typedef struct {
    int uppercase_count;
    int lowercase_count;
    int digit_count;
    int word_count;
} Statistics;

// Robust write helper
ssize_t write_full(int fd, const void *buf, size_t count) {
    size_t total = 0;
    while (total < count) {
        ssize_t w = write(fd, (const char *)buf + total, count - total);
        if (w == -1) {
            if (errno == EINTR) continue;
            return -1;
        }
        total += w;
    }
    return total;
}

// Robust read helper
ssize_t read_full(int fd, void *buf, size_t count) {
    size_t total = 0;
    while (total < count) {
        ssize_t r = read(fd, (char *)buf + total, count - total);
        if (r == -1) {
            if (errno == EINTR) continue;
            return -1;
        }
        if (r == 0) break; // EOF
        total += r;
    }
    return total;
}

void process_in_child(int read_fd, int write_fd) {
    while (1) {
        size_t len;
        if (read_full(read_fd, &len, sizeof(size_t)) <= 0) break;
        
        char *msg = malloc(len + 1);
        read_full(read_fd, msg, len);
        msg[len] = '\0';
        
        if (strcmp(msg, "exit") == 0) {
            free(msg);
            break;
        }
        
        Statistics stats = {0};
        int in_word = 0;
        
        // Count stats and toggle case
        for (size_t i = 0; i < len; i++) {
            if (isupper(msg[i])) {
                stats.uppercase_count++;
                msg[i] = tolower(msg[i]);
            } else if (islower(msg[i])) {
                stats.lowercase_count++;
                msg[i] = toupper(msg[i]);
            } else if (isdigit(msg[i])) {
                stats.digit_count++;
            }
            
            if (!isspace((unsigned char)msg[i])) {
                if (!in_word) { stats.word_count++; in_word = 1; }
            } else {
                in_word = 0;
            }
        }
        
        // Reverse words
        char *reversed = malloc(len + 1);
        reversed[0] = '\0';
        char *saveptr;
        // Tokenize backwards by storing pointers (simple approach for max 256 chars)
        char *words[256];
        int w_idx = 0;
        char *token = strtok_r(msg, " \t\n\r\v\f", &saveptr);
        while (token != NULL) {
            words[w_idx++] = token;
            token = strtok_r(NULL, " \t\n\r\v\f", &saveptr);
        }
        
        for (int i = w_idx - 1; i >= 0; i--) {
            strcat(reversed, words[i]);
            if (i > 0) strcat(reversed, " ");
        }
        
        size_t rev_len = strlen(reversed);
        
        // Send back to parent: length, string, stats
        write_full(write_fd, &rev_len, sizeof(size_t));
        write_full(write_fd, reversed, rev_len);
        write_full(write_fd, &stats, sizeof(Statistics));
        
        free(msg);
        free(reversed);
    }
    
    close(read_fd);
    close(write_fd);
    exit(0);
}

int main() {
    int p2c[2], c2p[2];
    
    if (pipe(p2c) == -1 || pipe(c2p) == -1) {
        perror("Pipe failed");
        exit(EXIT_FAILURE);
    }
    
    pid_t pid = fork();
    if (pid < 0) {
        perror("Fork failed");
        exit(EXIT_FAILURE);
    }
    
    if (pid == 0) {
        // Child
        close(p2c[1]); // Close Parent->Child write
        close(c2p[0]); // Close Child->Parent read
        
        process_in_child(p2c[0], c2p[1]);
    } else {
        // Parent
        close(p2c[0]); // Close Parent->Child read
        close(c2p[1]); // Close Child->Parent write
        
        printf("Parent PID: %d\n", getpid());
        printf("Child PID : %d\n", pid);
        
        char buffer[256];
        while (1) {
            printf("Enter a message: ");
            if (!fgets(buffer, sizeof(buffer), stdin)) break;
            
            // Remove trailing newline
            buffer[strcspn(buffer, "\n")] = 0;
            
            size_t len = strlen(buffer);
            write_full(p2c[1], &len, sizeof(size_t));
            write_full(p2c[1], buffer, len);
            
            if (strcmp(buffer, "exit") == 0) break;
            
            size_t rev_len;
            if (read_full(c2p[0], &rev_len, sizeof(size_t)) <= 0) break;
            
            char *transformed = malloc(rev_len + 1);
            read_full(c2p[0], transformed, rev_len);
            transformed[rev_len] = '\0';
            
            Statistics stats;
            read_full(c2p[0], &stats, sizeof(Statistics));
            
            printf("Transformed message : %s\n", transformed);
            printf("Uppercase letters   : %d\n", stats.uppercase_count);
            printf("Lowercase letters   : %d\n", stats.lowercase_count);
            printf("Digits              : %d\n", stats.digit_count);
            printf("Words               : %d\n", stats.word_count);
            
            free(transformed);
        }
        
        close(p2c[1]);
        close(c2p[0]);
        
        int status;
        waitpid(pid, &status, 0);
        if (WIFEXITED(status)) {
            printf("Child terminated normally with exit status %d.\n", WEXITSTATUS(status));
        } else {
            printf("Child terminated abnormally.\n");
        }
        printf("Parent terminating.\n");
    }
    
    return 0;
}