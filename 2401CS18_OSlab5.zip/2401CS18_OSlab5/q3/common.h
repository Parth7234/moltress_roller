#ifndef COMMON_H
#define COMMON_H

#include <unistd.h>
#include <errno.h>

#define TOPIC_LENGTH 100
#define ARTICLE_LENGTH 200

typedef struct {
    int journalist_id;
    int article_number;
    char topic[TOPIC_LENGTH];
    char article_text[ARTICLE_LENGTH];
} ArticleMessage;

typedef enum { CONTROL_STOP = 1, CONTROL_GO = 2 } ControlType;

typedef struct {
    ControlType type;
} ControlMessage;

// Robust I/O helpers handling EINTR and partial transfers
ssize_t read_full(int fd, void *buf, size_t count) {
    size_t total = 0;
    while (total < count) {
        ssize_t r = read(fd, (char *)buf + total, count - total);
        if (r == -1) {
            if (errno == EINTR) continue;
            return -1;
        }
        if (r == 0) break;
        total += r;
    }
    return total;
}

ssize_t write_full(int fd, const void *buf, size_t count) {
    size_t total = 0;
    while (total < count) {
        ssize_t w = write(fd, (const char *)buf + total, count - total);
        if (w == -1) {
            if (errno == EINTR) continue;
            return -1;
        }
        total += w;
    }
    return total;
}

#endif