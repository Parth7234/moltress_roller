#include "common.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define QUEUE_CAPACITY 3

typedef struct {
  char topics[QUEUE_CAPACITY][TOPIC_LENGTH];
  int head, tail, count;
  pthread_mutex_t mutex;
  pthread_cond_t not_empty, not_full;
} TopicQueue;

typedef struct {
  ArticleMessage articles[QUEUE_CAPACITY];
  int head, tail, count;
  pthread_mutex_t mutex;
  pthread_cond_t not_empty, not_full;
} ArticleQueue;

int shutdown_flag = 0;
TopicQueue tq = {.head = 0,
                 .tail = 0,
                 .count = 0,
                 .mutex = PTHREAD_MUTEX_INITIALIZER,
                 .not_empty = PTHREAD_COND_INITIALIZER,
                 .not_full = PTHREAD_COND_INITIALIZER};
ArticleQueue aq = {.head = 0,
                   .tail = 0,
                   .count = 0,
                   .mutex = PTHREAD_MUTEX_INITIALIZER,
                   .not_empty = PTHREAD_COND_INITIALIZER,
                   .not_full = PTHREAD_COND_INITIALIZER};

int j_id, article_fd, control_fd;

void *researcher(void *arg) {
  int t_num = 1;
  while (1) {
    pthread_mutex_lock(&tq.mutex);
    while (tq.count == QUEUE_CAPACITY && !shutdown_flag)
      pthread_cond_wait(&tq.not_full, &tq.mutex);
    if (shutdown_flag) {
      pthread_mutex_unlock(&tq.mutex);
      break;
    }

    snprintf(tq.topics[tq.tail], TOPIC_LENGTH, "Topic %d from Journalist %d",
             t_num++, j_id);
    tq.tail = (tq.tail + 1) % QUEUE_CAPACITY;
    tq.count++;

    pthread_cond_signal(&tq.not_empty);
    pthread_mutex_unlock(&tq.mutex);

    usleep(50000);
  }
  return NULL;
}

void *writer(void *arg) {
  while (1) {
    char current_topic[TOPIC_LENGTH];

    // Read Topic
    pthread_mutex_lock(&tq.mutex);
    while (tq.count == 0 && !shutdown_flag)
      pthread_cond_wait(&tq.not_empty, &tq.mutex);
    if (shutdown_flag && tq.count == 0) {
      pthread_mutex_unlock(&tq.mutex);
      break;
    }

    strcpy(current_topic, tq.topics[tq.head]);
    tq.head = (tq.head + 1) % QUEUE_CAPACITY;
    tq.count--;
    pthread_cond_signal(&tq.not_full);
    pthread_mutex_unlock(&tq.mutex);

    // Write Article
    pthread_mutex_lock(&aq.mutex);
    while (aq.count == QUEUE_CAPACITY && !shutdown_flag)
      pthread_cond_wait(&aq.not_full, &aq.mutex);
    if (shutdown_flag) {
      pthread_mutex_unlock(&aq.mutex);
      break;
    }

    ArticleMessage msg;
    msg.journalist_id = j_id;
    msg.article_number = 1; // Simplify logic
    strcpy(msg.topic, current_topic);
    snprintf(msg.article_text, ARTICLE_LENGTH, "Content for %s", current_topic);

    aq.articles[aq.tail] = msg;
    aq.tail = (aq.tail + 1) % QUEUE_CAPACITY;
    aq.count++;

    pthread_cond_signal(&aq.not_empty);
    pthread_mutex_unlock(&aq.mutex);
  }
  return NULL;
}

void *submitter(void *arg) {
  while (1) {
    pthread_mutex_lock(&aq.mutex);
    while (aq.count == 0 && !shutdown_flag)
      pthread_cond_wait(&aq.not_empty, &aq.mutex);
    if (shutdown_flag && aq.count == 0) {
      pthread_mutex_unlock(&aq.mutex);
      break;
    }

    ArticleMessage msg = aq.articles[aq.head];
    aq.head = (aq.head + 1) % QUEUE_CAPACITY;
    aq.count--;
    pthread_cond_signal(&aq.not_full);
    pthread_mutex_unlock(&aq.mutex);

    write_full(article_fd, &msg, sizeof(ArticleMessage));
  }
  return NULL;
}

int main(int argc, char *argv[]) {
  if (argc != 4)
    exit(EXIT_FAILURE);

  j_id = atoi(argv[1]);
  article_fd = atoi(argv[2]);
  control_fd = atoi(argv[3]);

  // Wait for the editor to signal GO (ensures all journalists start together)
  ControlMessage go_ctrl;
  if (read_full(control_fd, &go_ctrl, sizeof(ControlMessage)) <= 0 ||
      go_ctrl.type != CONTROL_GO) {
    fprintf(stderr, "Journalist %d: failed to receive GO signal\n", j_id);
    exit(EXIT_FAILURE);
  }

  pthread_t th_res, th_wri, th_sub;
  pthread_create(&th_res, NULL, researcher, NULL);
  pthread_create(&th_wri, NULL, writer, NULL);
  pthread_create(&th_sub, NULL, submitter, NULL);

  ControlMessage ctrl;
  while (read_full(control_fd, &ctrl, sizeof(ControlMessage)) > 0) {
    if (ctrl.type == CONTROL_STOP) {
      pthread_mutex_lock(&tq.mutex);
      pthread_mutex_lock(&aq.mutex);

      shutdown_flag = 1;

      pthread_cond_broadcast(&tq.not_empty);
      pthread_cond_broadcast(&tq.not_full);
      pthread_cond_broadcast(&aq.not_empty);
      pthread_cond_broadcast(&aq.not_full);

      pthread_mutex_unlock(&aq.mutex);
      pthread_mutex_unlock(&tq.mutex);
      break;
    }
  }

  pthread_join(th_res, NULL);
  pthread_join(th_wri, NULL);
  pthread_join(th_sub, NULL);

  close(article_fd);
  close(control_fd);
  exit(EXIT_SUCCESS);
}