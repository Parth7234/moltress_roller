#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/select.h>
#include <fcntl.h>
#include "common.h"

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <journalists N> <publication target M>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    long N = strtol(argv[1], NULL, 10);
    long M = strtol(argv[2], NULL, 10);
    if (N < 1 || N > 10 || M < 1 || M > 100) {
        fprintf(stderr, "Error: 1 <= N <= 10, 1 <= M <= 100\n"); exit(EXIT_FAILURE);
    }

    int article_pipes[N][2], control_pipes[N][2];
    pid_t pids[N];
    int counts[N];
    memset(counts, 0, sizeof(counts));

    for (int i = 0; i < N; i++) {
        pipe(article_pipes[i]);
        pipe(control_pipes[i]);

        pids[i] = fork();
        if (pids[i] == 0) {
            // Child: setup descriptors and execvp
            close(article_pipes[i][0]);
            close(control_pipes[i][1]);
            
            for (int j = 0; j < i; j++) {
                close(article_pipes[j][0]);   // parent's article read end
                close(control_pipes[j][1]);   // parent's control write end
            }

            char id_str[10], art_fd_str[10], ctrl_fd_str[10];
            sprintf(id_str, "%d", i + 1);
            sprintf(art_fd_str, "%d", article_pipes[i][1]);
            sprintf(ctrl_fd_str, "%d", control_pipes[i][0]);

            char *args[] = {"./journalist", id_str, art_fd_str, ctrl_fd_str, NULL};
            execvp(args[0], args);
            perror("execvp failed"); exit(EXIT_FAILURE);
        }
        // Parent: close unused ends
        close(article_pipes[i][1]);
        close(control_pipes[i][0]);
    }

    // Signal all journalists to start producing at the same time
    ControlMessage go_msg = { CONTROL_GO };
    for (int i = 0; i < N; i++) {
        write_full(control_pipes[i][1], &go_msg, sizeof(ControlMessage));
    }

    int published = 0;
    fd_set read_fds;
    int max_fd = 0;
    int next_journalist = 0;

    // Set article pipes to non-blocking so we can do fair polling
    for (int i = 0; i < N; i++) {
        int flags = fcntl(article_pipes[i][0], F_GETFL, 0);
        fcntl(article_pipes[i][0], F_SETFL, flags | O_NONBLOCK);
    }

    // Fair round-robin scheduling: read one article at a time, cycling through journalists
    while (published < M) {
        int i = next_journalist;

        // Try a non-blocking read from the current journalist
        ArticleMessage msg;
        ssize_t r = read(article_pipes[i][0], &msg, sizeof(ArticleMessage));

        if (r == sizeof(ArticleMessage)) {
            published++;
            counts[msg.journalist_id - 1]++;
            printf("Published Article %d: [Journalist %d] %s\n", published, msg.journalist_id, msg.topic);
        } else if (r > 0) {
            // Partial read: read the rest (blocking is OK for completion)
            char *buf = (char *)&msg;
            size_t remaining = sizeof(ArticleMessage) - r;
            while (remaining > 0) {
                ssize_t r2 = read(article_pipes[i][0], buf + sizeof(ArticleMessage) - remaining, remaining);
                if (r2 > 0) remaining -= r2;
                else if (r2 == -1 && (errno == EAGAIN || errno == EWOULDBLOCK)) {
                    usleep(1000);
                } else break;
            }
            if (remaining == 0) {
                published++;
                counts[msg.journalist_id - 1]++;
                printf("Published Article %d: [Journalist %d] %s\n", published, msg.journalist_id, msg.topic);
            }
        } else {
            // No data from this journalist (EAGAIN), use select to wait for any pipe
            FD_ZERO(&read_fds);
            max_fd = 0;
            for (int j = 0; j < N; j++) {
                FD_SET(article_pipes[j][0], &read_fds);
                if (article_pipes[j][0] > max_fd) max_fd = article_pipes[j][0];
            }
            struct timeval tv = { .tv_sec = 0, .tv_usec = 5000 }; // 5ms
            select(max_fd + 1, &read_fds, NULL, NULL, &tv);
        }

        // Always advance to the next journalist (strict round-robin)
        next_journalist = (next_journalist + 1) % N;
    }

    // Initiate shutdown
    ControlMessage stop_msg = { CONTROL_STOP };
    for (int i = 0; i < N; i++) {
        write_full(control_pipes[i][1], &stop_msg, sizeof(ControlMessage));
        close(control_pipes[i][1]);
    }

    // Set pipes back to blocking for drain, then drain
    for (int i = 0; i < N; i++) {
        int flags = fcntl(article_pipes[i][0], F_GETFL, 0);
        fcntl(article_pipes[i][0], F_SETFL, flags & ~O_NONBLOCK);
        ArticleMessage dummy;
        while (read_full(article_pipes[i][0], &dummy, sizeof(ArticleMessage)) > 0);
        close(article_pipes[i][0]);
    }

    // Wait and summarize
    int all_normal = 1;
    for (int i = 0; i < N; i++) {
        int status;
        waitpid(pids[i], &status, 0);
        if (!WIFEXITED(status)) all_normal = 0;
    }

    printf("\nNewsroom summary:\n");
    printf("Total articles published: %d\n", published);
    int max_count = 0;
    for (int i = 0; i < N; i++) {
        printf("Journalist %d          : %d\n", i + 1, counts[i]);
        if (counts[i] > max_count) max_count = counts[i];
    }
    printf("Highest contribution    :");
    for (int i = 0; i < N; i++) {
        if (counts[i] == max_count) printf(" Journalist %d", i + 1);
    }
    printf("\n");
    if (all_normal) printf("All journalists exited normally.\n");

    return 0;
}