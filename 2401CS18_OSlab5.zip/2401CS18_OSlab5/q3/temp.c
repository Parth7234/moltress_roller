#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <errno.h>
#include <limits.h>
int main(int argc, char *argv[]) {
// 1. Argument Validation
if (argc != 2) {
fprintf(stderr, "Usage: %s <n>\n", argv[0]);
exit(EXIT_FAILURE);
}
char *endptr;
errno = 0; // To distinguish success/failure after call
long n = strtol(argv[1], &endptr, 10);
// Check for various possible errors
if ((errno == ERANGE && (n == LONG_MAX || n == LONG_MIN)) || (errno != 0 && n == 0)) {
perror("strtol");
exit(EXIT_FAILURE);
}
if (endptr == argv[1] || *endptr != '\0') {
fprintf(stderr, "Error: Invalid number format.\n");
exit(EXIT_FAILURE);
}
if (n < 1 || n > 40) {
fprintf(stderr, "Error: Number of terms must be between 1 and 40.\n");
exit(EXIT_FAILURE);
}
// 2. Prevent pre-fork buffered output from appearing twice
printf("Parent process:\n");
fflush(stdout);
// 3. Process Creation
pid_t pid = fork();
if (pid < 0) {
perror("Fork failed");
exit(EXIT_FAILURE);
}
if (pid == 0) {
// Child Process
printf("Child process:\n");
printf("Child PID : %d\n", getpid());
printf("Parent PID: %d\n", getppid());
printf("Fibonacci sequence: ");
long long a = 0, b = 1, next;
int even_count = 0;
for (int i = 0; i < n; i++) {
if (i == 0) {
printf("%lld ", a);
if (a % 2 == 0) even_count++;
} else if (i == 1) {
printf("%lld ", b);
if (b % 2 == 0) even_count++;
} else {
next = a + b;
a = b;
b = next;
printf("%lld ", next);
if (next % 2 == 0) even_count++;
}
}
printf("\nEven-valued terms: %d\n", even_count);
// Return the count as the exit status (valid since n <= 40, max even terms < 255)
exit(even_count);
} else {
// Parent Process
printf("Parent PID: %d\n", getpid());
printf("Child PID : %d\n\n", pid);
int status;
waitpid(pid, &status, 0);
printf("\nParent process:\n");
if (WIFEXITED(status)) {
int child_even_count = WEXITSTATUS(status);
printf("Child %d terminated normally.\n", pid);
printf("Even-term count returned by child: %d\n", child_even_count);
} else if (WIFSIGNALED(status)) {
printf("Child %d terminated by signal %d.\n", pid, WTERMSIG(status));
}
printf("Parent terminating.\n");
}
return 0;
}