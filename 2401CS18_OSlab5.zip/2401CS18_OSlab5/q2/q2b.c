#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <errno.h>
#include <limits.h>
#include <string.h>

#define MAX_SEQUENCE 40

typedef struct {
    long fib_sequence[MAX_SEQUENCE];
    int sequence_size;
    long sequence_sum;
    int even_count;
    int odd_count;
    int generator_completed;
    int analyser_completed;
} SharedData;

void cleanup_shm(SharedData *ptr, int fd, const char *name) {
    if (ptr != MAP_FAILED) munmap(ptr, sizeof(SharedData));
    if (fd != -1) close(fd);
    if (name != NULL) shm_unlink(name);
}

int main(int argc, char *argv[]) {
    // 1. Validate Input
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <n>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    char *endptr;
    errno = 0;
    long n = strtol(argv[1], &endptr, 10);

    if ((errno == ERANGE && (n == LONG_MAX || n == LONG_MIN)) || (errno != 0 && n == 0)) {
        perror("strtol"); exit(EXIT_FAILURE);
    }
    if (endptr == argv[1] || *endptr != '\0') {
        fprintf(stderr, "Error: Invalid number format.\n"); exit(EXIT_FAILURE);
    }
    if (n < 1 || n > MAX_SEQUENCE) {
        fprintf(stderr, "Error: Number of terms must be between 1 and 40.\n"); exit(EXIT_FAILURE);
    }

    printf("Parent PID: %d\n", getpid());

    // 2. Setup POSIX Shared Memory
    char shm_name[256];
    snprintf(shm_name, sizeof(shm_name), "/fibonacci_%d", getpid());

    int shm_fd = shm_open(shm_name, O_CREAT | O_RDWR, 0666);
    if (shm_fd == -1) {
        perror("shm_open failed"); exit(EXIT_FAILURE);
    }

    if (ftruncate(shm_fd, sizeof(SharedData)) == -1) {
        perror("ftruncate failed");
        cleanup_shm(MAP_FAILED, shm_fd, shm_name);
        exit(EXIT_FAILURE);
    }

    SharedData *shared_data = mmap(NULL, sizeof(SharedData), PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
    if (shared_data == MAP_FAILED) {
        perror("mmap failed");
        cleanup_shm(MAP_FAILED, shm_fd, shm_name);
        exit(EXIT_FAILURE);
    }

    // Initialize SharedData
    memset(shared_data, 0, sizeof(SharedData));
    printf("Shared-memory object created.\n");
    fflush(stdout);

    // 3. Create Generator Child
    pid_t gen_pid = fork();
    if (gen_pid < 0) {
        perror("Fork (Generator) failed");
        cleanup_shm(shared_data, shm_fd, shm_name);
        exit(EXIT_FAILURE);
    }

    if (gen_pid == 0) {
        // Generator Logic
        shared_data->sequence_size = n;
        long a = 0, b = 1, next;
        
        for (int i = 0; i < n; i++) {
            if (i == 0) {
                shared_data->fib_sequence[i] = a;
            } else if (i == 1) {
                shared_data->fib_sequence[i] = b;
            } else {
                next = a + b;
                a = b;
                b = next;
                shared_data->fib_sequence[i] = next;
            }
        }
        
        shared_data->generator_completed = 1;
        printf("Generator child PID: %d\n", getpid());
        printf("Generator completed successfully.\n");
        
        munmap(shared_data, sizeof(SharedData));
        close(shm_fd);
        exit(EXIT_SUCCESS);
    }

    // Wait for Generator
    int status;
    waitpid(gen_pid, &status, 0);
    if (!WIFEXITED(status) || WEXITSTATUS(status) != 0 || shared_data->generator_completed != 1) {
        fprintf(stderr, "Generator failed. Aborting.\n");
        cleanup_shm(shared_data, shm_fd, shm_name);
        exit(EXIT_FAILURE);
    }

    // 4. Create Analyser Child
    pid_t ana_pid = fork();
    if (ana_pid < 0) {
        perror("Fork (Analyser) failed");
        cleanup_shm(shared_data, shm_fd, shm_name);
        exit(EXIT_FAILURE);
    }

    if (ana_pid == 0) {
        // Analyser Logic
        if (shared_data->generator_completed != 1) {
            fprintf(stderr, "Analyser: Generator did not complete.\n");
            munmap(shared_data, sizeof(SharedData)); close(shm_fd); exit(EXIT_FAILURE);
        }

        long sum = 0;
        int even = 0, odd = 0;
        int size = shared_data->sequence_size;

        for (int i = 0; i < size; i++) {
            long val = shared_data->fib_sequence[i];
            sum += val;
            if (val % 2 == 0) even++;
            else odd++;
        }

        shared_data->sequence_sum = sum;
        shared_data->even_count = even;
        shared_data->odd_count = odd;
        shared_data->analyser_completed = 1;

        printf("Analyser child PID: %d\n", getpid());
        printf("Analyser completed successfully.\n");

        munmap(shared_data, sizeof(SharedData));
        close(shm_fd);
        exit(EXIT_SUCCESS);
    }

    // Wait for Analyser
    waitpid(ana_pid, &status, 0);
    if (!WIFEXITED(status) || WEXITSTATUS(status) != 0 || shared_data->analyser_completed != 1) {
        fprintf(stderr, "Analyser failed.\n");
    } else {
        // 5. Parent Prints Results
        printf("Final result printed by parent:\n");
        printf("Fibonacci sequence:");
        for (int i = 0; i < shared_data->sequence_size; i++) {
            printf(" %ld", shared_data->fib_sequence[i]);
        }
        printf("\n");
        printf("Sequence sum      : %ld\n", shared_data->sequence_sum);
        printf("Even-valued terms : %d\n", shared_data->even_count);
        printf("Odd-valued terms  : %d\n", shared_data->odd_count);
    }

    // 6. Cleanup by Parent
    cleanup_shm(shared_data, shm_fd, shm_name);
    printf("Shared-memory object removed.\n");

    return 0;
}