#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <stdbool.h>
#include <errno.h>

#define CAPACITY 10

typedef struct {
    int task_id;
    int input_value;
    int squared_value;
    int producer_id;
    int processor_id;
} WorkItem; 

typedef struct {
    WorkItem items[CAPACITY];
    int front;
    int rear;
    int count;
    pthread_mutex_t mutex;
    pthread_cond_t not_empty;
    pthread_cond_t not_full;
} CircularBuffer; 

// Global Configuration & State
int N, seed_val;
CircularBuffer input_buffer, output_buffer;
FILE* log_file;
bool error_flag = false;

// Shared Counters and Mutexes
int next_task_id = 1;
pthread_mutex_t task_id_mutex = PTHREAD_MUTEX_INITIALIZER;

int producers_finished = 0;
pthread_mutex_t prod_fin_mutex = PTHREAD_MUTEX_INITIALIZER;

int processors_finished = 0;
pthread_mutex_t proc_fin_mutex = PTHREAD_MUTEX_INITIALIZER;

// Statistics
int prod_counts[2] = {0, 0};
int proc_counts[2] = {0, 0};
long long input_sum = 0;
long long squared_sum = 0;
int consumed_count = 0;
int integrity_failures = 0;

void init_buffer(CircularBuffer* b) {
    b->front = 0;
    b->rear = 0;
    b->count = 0;
    pthread_mutex_init(&b->mutex, NULL);
    pthread_cond_init(&b->not_empty, NULL);
    pthread_cond_init(&b->not_full, NULL);
}

void* producer_func(void* arg) {
    int id = *(int*)arg;
    unsigned int seed = seed_val + id; 
    
    while (1) {
        if (error_flag) break;
        
        pthread_mutex_lock(&task_id_mutex);
        if (next_task_id > N) {
            pthread_mutex_unlock(&task_id_mutex);
            break;
        }
        int my_task_id = next_task_id++; 
        pthread_mutex_unlock(&task_id_mutex);
        
        WorkItem item;
        item.task_id = my_task_id;
        item.input_value = rand_r(&seed) % 100; 
        item.producer_id = id + 1;
        
        // Real-time message
        printf("Producer %d produced task %d: value=%d\n", item.producer_id, item.task_id, item.input_value);
        
        pthread_mutex_lock(&input_buffer.mutex);
        while (input_buffer.count == CAPACITY && !error_flag) {
            pthread_cond_wait(&input_buffer.not_full, &input_buffer.mutex); 
        }
        if (error_flag) { pthread_mutex_unlock(&input_buffer.mutex); break; }
        
        input_buffer.items[input_buffer.rear] = item;
        input_buffer.rear = (input_buffer.rear + 1) % CAPACITY;
        input_buffer.count++;
        prod_counts[id]++;
        
        pthread_cond_signal(&input_buffer.not_empty); 
        pthread_mutex_unlock(&input_buffer.mutex);
    }
    
    pthread_mutex_lock(&prod_fin_mutex);
    producers_finished++;
    if (producers_finished == 2) {
        pthread_mutex_lock(&input_buffer.mutex);
        pthread_cond_broadcast(&input_buffer.not_empty); 
        pthread_mutex_unlock(&input_buffer.mutex);
    }
    pthread_mutex_unlock(&prod_fin_mutex);
    return NULL;
}

void* processor_func(void* arg) {
    int id = *(int*)arg;
    
    while (1) {
        if (error_flag) break;
        
        pthread_mutex_lock(&input_buffer.mutex);
        while (input_buffer.count == 0) {
            pthread_mutex_lock(&prod_fin_mutex);
            int p_fin = producers_finished;
            pthread_mutex_unlock(&prod_fin_mutex);
            
            if (p_fin == 2 && input_buffer.count == 0) { 
                pthread_mutex_unlock(&input_buffer.mutex);
                goto proc_exit;
            }
            if (error_flag) { pthread_mutex_unlock(&input_buffer.mutex); goto proc_exit; }
            pthread_cond_wait(&input_buffer.not_empty, &input_buffer.mutex); 
        }
        
        WorkItem item = input_buffer.items[input_buffer.front];
        input_buffer.front = (input_buffer.front + 1) % CAPACITY;
        input_buffer.count--;
        
        pthread_cond_signal(&input_buffer.not_full); 
        pthread_mutex_unlock(&input_buffer.mutex);
        
        // Computation outside critical section
        item.squared_value = item.input_value * item.input_value; 
        item.processor_id = id + 1;
        
        // Real-time message
        printf("Processor %d processed task %d: %d -> %d\n", item.processor_id, item.task_id, item.input_value, item.squared_value);
        
        pthread_mutex_lock(&output_buffer.mutex);
        while (output_buffer.count == CAPACITY && !error_flag) {
            pthread_cond_wait(&output_buffer.not_full, &output_buffer.mutex);
        }
        if (error_flag) { pthread_mutex_unlock(&output_buffer.mutex); break; }
        
        output_buffer.items[output_buffer.rear] = item;
        output_buffer.rear = (output_buffer.rear + 1) % CAPACITY;
        output_buffer.count++;
        proc_counts[id]++;
        
        pthread_cond_signal(&output_buffer.not_empty); 
        pthread_mutex_unlock(&output_buffer.mutex);
    }
    
proc_exit:
    pthread_mutex_lock(&proc_fin_mutex);
    processors_finished++;
    if (processors_finished == 2) {
        pthread_mutex_lock(&output_buffer.mutex);
        pthread_cond_broadcast(&output_buffer.not_empty); 
        pthread_mutex_unlock(&output_buffer.mutex);
    }
    pthread_mutex_unlock(&proc_fin_mutex);
    return NULL;
}

void* consumer_func(void* arg) {
    WorkItem* results = calloc(N + 1, sizeof(WorkItem)); 
    int* seen = calloc(N + 1, sizeof(int));
    
    while (1) {
        if (error_flag) break;
        
        pthread_mutex_lock(&output_buffer.mutex);
        while (output_buffer.count == 0) {
            pthread_mutex_lock(&proc_fin_mutex);
            int p_fin = processors_finished;
            pthread_mutex_unlock(&proc_fin_mutex);
            
            if (p_fin == 2 && output_buffer.count == 0) { 
                pthread_mutex_unlock(&output_buffer.mutex);
                goto cons_exit;
            }
            if (error_flag) { pthread_mutex_unlock(&output_buffer.mutex); goto cons_exit; }
            pthread_cond_wait(&output_buffer.not_empty, &output_buffer.mutex); 
        }
        
        WorkItem item = output_buffer.items[output_buffer.front];
        output_buffer.front = (output_buffer.front + 1) % CAPACITY;
        output_buffer.count--;
        
        pthread_cond_signal(&output_buffer.not_full);
        pthread_mutex_unlock(&output_buffer.mutex);
        
        // Real-time message
        printf("Consumer received task %d.\n", item.task_id);
        
        if (item.task_id < 1 || item.task_id > N || seen[item.task_id]) {
            integrity_failures++; 
        } else {
            if (item.squared_value != item.input_value * item.input_value) integrity_failures++; 
            seen[item.task_id] = 1;
            results[item.task_id] = item;
            input_sum += item.input_value;
            squared_sum += item.squared_value;
            consumed_count++;
        }
    }
    
cons_exit:
    if (!error_flag) {
        for (int i = 1; i <= N; i++) {
            if (seen[i]) {
                fprintf(log_file, "Task %d: input=%d, square=%d, producer=%d, processor=%d\n",
                        results[i].task_id, results[i].input_value, results[i].squared_value,
                        results[i].producer_id, results[i].processor_id); 
            } else {
                integrity_failures++; 
            }
        }
    }
    free(results);
    free(seen);
    return NULL;
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: ./pipeline <number-of-items> <random-seed>\n");
        return EXIT_FAILURE;
    }
    
    char* endptr;
    N = strtol(argv[1], &endptr, 10); 
    if (*endptr != '\0' || N < 10 || N > 500) { 
        fprintf(stderr, "Invalid N. Must be between 10 and 500.\n");
        return EXIT_FAILURE;
    }
    
    seed_val = strtol(argv[2], &endptr, 10);
    if (*endptr != '\0' || seed_val < 0) { 
        fprintf(stderr, "Invalid seed. Must be non-negative.\n");
        return EXIT_FAILURE;
    }
    
    log_file = fopen("log.txt", "w"); 
    if (!log_file) {
        perror("Failed to open log.txt");
        return EXIT_FAILURE;
    }
    
    init_buffer(&input_buffer);
    init_buffer(&output_buffer);
    
    // Print the starting message BEFORE thread creation
    printf("Pipeline started: items=%d, capacity=10, seed=%d\n", N, seed_val);
    
    pthread_t producers[2], processors[2], consumer;
    int p_ids[2] = {0, 1};
    
    if (pthread_create(&producers[0], NULL, producer_func, &p_ids[0]) != 0 ||
        pthread_create(&producers[1], NULL, producer_func, &p_ids[1]) != 0 ||
        pthread_create(&processors[0], NULL, processor_func, &p_ids[0]) != 0 ||
        pthread_create(&processors[1], NULL, processor_func, &p_ids[1]) != 0 ||
        pthread_create(&consumer, NULL, consumer_func, NULL) != 0) {
        error_flag = true; 
    }
    
    if (error_flag) {
        pthread_cond_broadcast(&input_buffer.not_empty);
        pthread_cond_broadcast(&input_buffer.not_full);
        pthread_cond_broadcast(&output_buffer.not_empty);
        pthread_cond_broadcast(&output_buffer.not_full);
    }
    
    // Joins
    pthread_join(producers[0], NULL); pthread_join(producers[1], NULL);
    pthread_join(processors[0], NULL); pthread_join(processors[1], NULL);
    pthread_join(consumer, NULL); 
    
    fclose(log_file); 
    
    if (error_flag) return EXIT_FAILURE; 
    
    int total_produced = prod_counts[0] + prod_counts[1];
    int total_processed = proc_counts[0] + proc_counts[1];
    
    printf("=== Pipeline Summary ===\n");
    printf("Requested/Produced/Processed/Consumed: %d/%d/%d/%d\n", N, total_produced, total_processed, consumed_count); 
    printf("Producer counts: %d %d\n", prod_counts[0], prod_counts[1]); 
    printf("Processor counts: %d %d\n", proc_counts[0], proc_counts[1]); 
    printf("Input-value sum: %lld\n", input_sum); 
    printf("Squared-value sum: %lld\n", squared_sum); 
    printf("Integrity failures: %d\n", integrity_failures); 
    
    bool passed = (total_produced == N && total_processed == N && consumed_count == N && 
                   integrity_failures == 0 && input_buffer.count == 0 && output_buffer.count == 0); 
                   
    printf("Pipeline integrity check: %s\n", passed ? "PASSED" : "FAILED"); 
    if (passed) printf("Results written to log.txt\n"); 
    
    return EXIT_SUCCESS;
}