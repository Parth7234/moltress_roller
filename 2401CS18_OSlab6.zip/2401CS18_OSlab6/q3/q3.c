#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include <stdbool.h>
#include <unistd.h>
#include <float.h>

typedef enum { NOT_ARRIVED, THINKING, HUNGRY, EATING, LEFT } PhilosopherState; 

typedef struct {
    int id;
    PhilosopherState state;
    int arrival_time;
    int leave_time;
    int ticket;
    struct timespec request_time;
    int assigned_forks[2];
    bool grant_flag;
    unsigned int seed;
    
    // Statistics
    int requests;
    int meals;
    int cancelled;
    int threshold_crossings;
    double total_wait;
    double max_wait;
    
    pthread_cond_t grant_cond; 
} Philosopher;

// Globals
int N, F;
int D_duration;
double T_threshold;
unsigned int global_seed;

Philosopher *philosophers;
bool *forks; 
int available_forks;
bool banquet_closed = false;

// Monitor Variables
pthread_mutex_t monitor_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t waiter_cond = PTHREAD_COND_INITIALIZER;
int next_ticket = 1;
int forks_reserved = 0;
int fairness_violations = 0;
struct timespec start_time;

// Helper: Get monotonic time in seconds
double get_elapsed_time() {
    struct timespec now;
    clock_gettime(CLOCK_MONOTONIC, &now); 
    return (now.tv_sec - start_time.tv_sec) + (now.tv_nsec - start_time.tv_nsec) / 1e9;
}

// Helper: Wait difference in seconds
double diff_time(struct timespec start, struct timespec end) {
    return (end.tv_sec - start.tv_sec) + (end.tv_nsec - start.tv_nsec) / 1e9;
}

void msleep(int ms) {
    struct timespec ts;
    ts.tv_sec = ms / 1000;
    ts.tv_nsec = (ms % 1000) * 1000000;
    nanosleep(&ts, NULL); 
}

void* philosopher_func(void* arg) {
    Philosopher* p = (Philosopher*)arg;
    
    // Simulate arrival delay
    msleep(p->arrival_time * 1000); 
    
    pthread_mutex_lock(&monitor_mutex);
    p->state = THINKING;
    pthread_mutex_unlock(&monitor_mutex);
    
    while (1) {
        // 1. Think
        int think_ms = 100 + rand_r(&p->seed) % 301;
        msleep(think_ms);
        
        pthread_mutex_lock(&monitor_mutex);
        
        // Check departure or closure
        if (banquet_closed || get_elapsed_time() >= p->leave_time) {
            p->state = LEFT;
            pthread_cond_signal(&waiter_cond);
            pthread_mutex_unlock(&monitor_mutex);
            break;
        }
        
        // 2. Become HUNGRY
        p->state = HUNGRY;
        p->ticket = next_ticket++;
        clock_gettime(CLOCK_MONOTONIC, &p->request_time);
        p->grant_flag = false;
        p->requests++;
        
        pthread_cond_signal(&waiter_cond); //
        
        // Wait for forks
        while (!p->grant_flag && !banquet_closed && get_elapsed_time() < p->leave_time) {
            // Using standard cond_wait for simplicity in simulation, relying on waiter broadcasts
            pthread_cond_wait(&p->grant_cond, &monitor_mutex);
        }
        
        if (!p->grant_flag) {
            // Cancelled
            p->cancelled++;
            p->state = LEFT;
            pthread_cond_signal(&waiter_cond);
            pthread_mutex_unlock(&monitor_mutex);
            break;
        }
        
        // 3. Granted, verify forks and record wait
        struct timespec now;
        clock_gettime(CLOCK_MONOTONIC, &now);
        double wait_time = diff_time(p->request_time, now);
        p->total_wait += wait_time;
        if (wait_time > p->max_wait) p->max_wait = wait_time;
        if (wait_time >= T_threshold) p->threshold_crossings++;
        
        pthread_mutex_unlock(&monitor_mutex);
        
        // Eat outside mutex
        int eat_ms = 100 + rand_r(&p->seed) % 201;
        msleep(eat_ms);
        
        // 4. Re-lock and release forks
        pthread_mutex_lock(&monitor_mutex);
        forks[p->assigned_forks[0]] = true;
        forks[p->assigned_forks[1]] = true;
        available_forks += 2;
        forks_reserved -= 2;
        p->meals++;
        p->state = THINKING;
        pthread_cond_signal(&waiter_cond); 
        pthread_mutex_unlock(&monitor_mutex);
    }
    
    return NULL;
}

void* waiter_func(void* arg) {
    pthread_mutex_lock(&monitor_mutex);
    
    while (1) {
        double elapsed = get_elapsed_time();
        
        if (elapsed >= D_duration && !banquet_closed) {
            banquet_closed = true; 
            for (int i = 0; i < N; i++) {
                if (philosophers[i].state == HUNGRY) {
                    philosophers[i].cancelled++; 
                    philosophers[i].state = LEFT;
                }
                pthread_cond_broadcast(&philosophers[i].grant_cond); 
            }
        }
        
        if (banquet_closed && forks_reserved == 0) {
            break; // Exit when closed and all forks returned
        }
        
        // Scheduling Policy
        if (available_forks >= 2 && !banquet_closed) {
            int best_idx = -1;
            bool found_urgent = false;
            
            // First pass: look for urgent requests
            for (int i = 0; i < N; i++) {
                if (philosophers[i].state == HUNGRY) {
                    struct timespec now;
                    clock_gettime(CLOCK_MONOTONIC, &now);
                    double w = diff_time(philosophers[i].request_time, now);
                    
                    if (w >= T_threshold) {
                        if (!found_urgent || 
                            diff_time(philosophers[best_idx].request_time, philosophers[i].request_time) < 0 ||
                            (diff_time(philosophers[best_idx].request_time, philosophers[i].request_time) == 0 && philosophers[i].ticket < philosophers[best_idx].ticket)) {
                            best_idx = i;
                            found_urgent = true;
                        }
                    }
                }
            }
            
            // Second pass: if no urgent, select by fewest meals
            if (!found_urgent) {
                for (int i = 0; i < N; i++) {
                    if (philosophers[i].state == HUNGRY) {
                        if (best_idx == -1 ||
                            philosophers[i].meals < philosophers[best_idx].meals ||
                            (philosophers[i].meals == philosophers[best_idx].meals && diff_time(philosophers[best_idx].request_time, philosophers[i].request_time) < 0) ||
                            (philosophers[i].meals == philosophers[best_idx].meals && diff_time(philosophers[best_idx].request_time, philosophers[i].request_time) == 0 && philosophers[i].ticket < philosophers[best_idx].ticket)) {
                            best_idx = i;
                        }
                    }
                }
            }
            
            if (best_idx != -1) {
                // Grant forks
                int f1 = -1, f2 = -1;
                for (int f = 0; f < F; f++) {
                    if (forks[f]) {
                        if (f1 == -1) f1 = f;
                        else if (f2 == -1) { f2 = f; break; }
                    }
                }
                
                forks[f1] = false; forks[f2] = false;
                available_forks -= 2;
                forks_reserved += 2;
                
                philosophers[best_idx].assigned_forks[0] = f1;
                philosophers[best_idx].assigned_forks[1] = f2;
                philosophers[best_idx].grant_flag = true;
                philosophers[best_idx].state = EATING; //
                
                printf("Waiter grants forks %d and %d to Philosopher %d.\n", f1, f2, philosophers[best_idx].id);
                pthread_cond_signal(&philosophers[best_idx].grant_cond); //
                continue; // Re-evaluate immediately
            }
        }
        
        // Sleep if no action possible. Using timed wait to wake up for deadline
        struct timespec wait_time;
        clock_gettime(CLOCK_REALTIME, &wait_time); // POSIX standard requires REALTIME for absolute abstime wait
        wait_time.tv_sec += 1; 
        pthread_cond_timedwait(&waiter_cond, &monitor_mutex, &wait_time); 
    }
    
    pthread_mutex_unlock(&monitor_mutex);
    return NULL;
}

int main(int argc, char *argv[]) {
    if (argc != 6) {
        fprintf(stderr, "Usage: ./banquet <philosophers> <forks> <duration> <fairness-threshold> <seed>\n");
        return EXIT_FAILURE;
    }
    
    N = strtol(argv[1], NULL, 10);
    F = strtol(argv[2], NULL, 10);
    D_duration = strtol(argv[3], NULL, 10);
    T_threshold = strtod(argv[4], NULL);
    global_seed = strtoul(argv[5], NULL, 10);
    
    if (N < 3 || N > 20 || F < 2 || F >= N || D_duration < 5 || D_duration > 30 || T_threshold < 0.1 || T_threshold > 5.0) { 
        fprintf(stderr, "Invalid arguments.\n");
        return EXIT_FAILURE;
    }
    
    philosophers = calloc(N, sizeof(Philosopher));
    forks = calloc(F, sizeof(bool));
    available_forks = F;
    for (int i = 0; i < F; i++) forks[i] = true;
    
    // Deterministic Schedule Generation
    unsigned int gen_seed = global_seed;
    int zero_arrival_assigned = 0, early_leave_assigned = 0;
    
    for (int i = 0; i < N; i++) {
        philosophers[i].id = i;
        philosophers[i].state = NOT_ARRIVED;
        philosophers[i].seed = gen_seed + i;
        pthread_cond_init(&philosophers[i].grant_cond, NULL); 
        
        int max_A = (D_duration - 1 < 3) ? (D_duration - 1) : 3;
        philosophers[i].arrival_time = rand_r(&gen_seed) % (max_A + 1);
        
        int min_L = philosophers[i].arrival_time + 2;
        if (min_L > D_duration) min_L = D_duration;
        int diff = D_duration - min_L + 1;
        philosophers[i].leave_time = min_L + (diff > 0 ? rand_r(&gen_seed) % diff : 0);
        
        if (philosophers[i].arrival_time == 0) zero_arrival_assigned = 1;
        if (philosophers[i].leave_time < D_duration) early_leave_assigned = 1;
    }
    
    // Ensure schedule constraints
    if (!zero_arrival_assigned) philosophers[0].arrival_time = 0;
    if (!early_leave_assigned) {
        philosophers[N-1].leave_time = D_duration - 1;
        if (philosophers[N-1].leave_time < philosophers[N-1].arrival_time + 2)
            philosophers[N-1].arrival_time = 0;
    }
    
    printf("Royal Banquet opened: N=%d, F=%d, D=%d, T=%.3f\n", N, F, D_duration, T_threshold); 
    clock_gettime(CLOCK_MONOTONIC, &start_time);
    
    pthread_t waiter_thread;
    pthread_t *phil_threads = calloc(N, sizeof(pthread_t));
    
    pthread_create(&waiter_thread, NULL, waiter_func, NULL);
    for (int i = 0; i < N; i++) {
        pthread_create(&phil_threads[i], NULL, philosopher_func, &philosophers[i]);
    }
    
    // Joins
    for (int i = 0; i < N; i++) pthread_join(phil_threads[i], NULL);
    pthread_join(waiter_thread, NULL);
    
    // Output Statistics
    printf("\n=== Royal Banquet Report ===\n");
    int total_meals = 0;
    bool all_left = true;
    
    for (int i = 0; i < N; i++) {
        double avg_wait = philosophers[i].meals > 0 ? (philosophers[i].total_wait / philosophers[i].meals) : 0.0; 
        printf("Philosopher %d: requests=%d meals=%d cancelled=%d\n", 
               philosophers[i].id, philosophers[i].requests, philosophers[i].meals, philosophers[i].cancelled); 
        total_meals += philosophers[i].meals;
        if (philosophers[i].state != LEFT) all_left = false; 
    }
    
    printf("Total meals                 : %d\n", total_meals); 
    printf("Fairness-policy violations  : %d\n", fairness_violations); 
    printf("Forks still reserved        : %d\n", forks_reserved); 
    
    bool passed = (forks_reserved == 0 && all_left && fairness_violations == 0); 
    printf("Banquet integrity check     : %s\n", passed ? "PASSED" : "FAILED"); 
    
    free(philosophers); free(forks); free(phil_threads);
    return EXIT_SUCCESS;
}