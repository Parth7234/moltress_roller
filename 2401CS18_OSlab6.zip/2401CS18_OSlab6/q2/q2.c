#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include <stdbool.h>

#ifdef __APPLE__
// Custom barrier implementation for macOS compatibility
typedef struct {
    pthread_mutex_t mutex;
    pthread_cond_t cond;
    int count;
    int trip_count;
} pthread_barrier_t;

int pthread_barrier_init(pthread_barrier_t *barrier, const void *attr, unsigned int count) {
    if (count == 0) return -1;
    pthread_mutex_init(&barrier->mutex, 0);
    pthread_cond_init(&barrier->cond, 0);
    barrier->trip_count = count;
    barrier->count = 0;
    return 0;
}

int pthread_barrier_destroy(pthread_barrier_t *barrier) {
    pthread_mutex_destroy(&barrier->mutex);
    pthread_cond_destroy(&barrier->cond);
    return 0;
}

int pthread_barrier_wait(pthread_barrier_t *barrier) {
    pthread_mutex_lock(&barrier->mutex);
    barrier->count++;
    if (barrier->count >= barrier->trip_count) {
        barrier->count = 0; // Reset for reuse
        pthread_cond_broadcast(&barrier->cond);
        pthread_mutex_unlock(&barrier->mutex);
        return 1; 
    } else {
        pthread_cond_wait(&barrier->cond, &barrier->mutex);
        pthread_mutex_unlock(&barrier->mutex);
        return 0;
    }
}
#endif // __APPLE__

// Global Variables
long long *A, *B, *BT, *C_par, *C_seq;
long M, K, N, T;
unsigned int seed_val;
int *worker_counts;

// Synchronization Primitives
pthread_mutex_t gate_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t gate_cond = PTHREAD_COND_INITIALIZER;
int start_flag = 0;
int abort_flag = 0;

pthread_barrier_t phase_barrier;

pthread_mutex_t row_mutex = PTHREAD_MUTEX_INITIALIZER;
long next_row = 0;

// Timing utility
double get_time_ms(struct timespec start, struct timespec end) {
    return (end.tv_sec - start.tv_sec) * 1000.0 + (end.tv_nsec - start.tv_nsec) / 1000000.0;
}

void* worker_func(void* arg) {
    int t = *(int*)arg;

    // 1. Safe Start Gate
    pthread_mutex_lock(&gate_mutex);
    while (start_flag == 0 && abort_flag == 0) {
        pthread_cond_wait(&gate_cond, &gate_mutex); 
    }
    pthread_mutex_unlock(&gate_mutex);
    if (abort_flag) return NULL; 

    // 2. Phase 1: Parallel transposition of B into BT
    for (long j = t; j < N; j += T) {
        for (long p = 0; p < K; p++) {
            BT[j * K + p] = B[p * N + j]; 
        }
    }

    // 3. Barrier: wait for all to finish transpose
    pthread_barrier_wait(&phase_barrier); 

    // 4. Phase 2: Dynamic row scheduling
    while (1) {
        pthread_mutex_lock(&row_mutex);
        long r = next_row++; //
        pthread_mutex_unlock(&row_mutex);

        if (r >= M) break;

        // Compute row r outside mutex
        for (long j = 0; j < N; j++) {
            long long sum = 0;
            for (long p = 0; p < K; p++) {
                sum += A[r * K + p] * BT[j * K + p];
            }
            C_par[r * N + j] = sum;
        }
        worker_counts[t]++; //
    }

    return NULL;
}

void print_matrix(const char* name, long long* mat, long rows, long cols) {
    printf("%s:\n", name);
    for (long i = 0; i < rows; i++) {
        for (long j = 0; j < cols; j++) {
            printf("%lld ", mat[i * cols + j]);
        }
        printf("\n");
    }
}

int main(int argc, char *argv[]) {
    if (argc != 6) {
        fprintf(stderr, "Usage: ./matmul <M> <K> <N> <threads> <seed>\n");
        return EXIT_FAILURE;
    }

    // Argument parsing
    M = strtol(argv[1], NULL, 10);
    K = strtol(argv[2], NULL, 10);
    N = strtol(argv[3], NULL, 10);
    T = strtol(argv[4], NULL, 10);
    seed_val = strtoul(argv[5], NULL, 10);

    if (M < 1 || K < 1 || N < 1 || N > 500 || T < 1 || T > (M < 32 ? M : 32)) { //
        fprintf(stderr, "Invalid dimensions or thread count.\n");
        return EXIT_FAILURE;
    }

    // Allocations
    A = calloc(M * K, sizeof(long long));
    B = calloc(K * N, sizeof(long long));
    BT = calloc(N * K, sizeof(long long));
    C_par = calloc(M * N, sizeof(long long));
    C_seq = calloc(M * N, sizeof(long long));
    worker_counts = calloc(T, sizeof(int));

    if (!A || !B || !BT || !C_par || !C_seq || !worker_counts) {
        fprintf(stderr, "Memory allocation failed.\n");
        return EXIT_FAILURE;
    }

    pthread_barrier_init(&phase_barrier, NULL, T); //

    // Initialization
    unsigned int seq_seed = seed_val;
    for (long i = 0; i < M * K; i++) A[i] = rand_r(&seq_seed) % 10; //
    for (long i = 0; i < K * N; i++) B[i] = rand_r(&seq_seed) % 10; //

    struct timespec start_seq, end_seq, start_par, end_par;

    // Sequential Computation and Timing
    clock_gettime(CLOCK_MONOTONIC, &start_seq);
    for (long i = 0; i < M; i++) {
        for (long j = 0; j < N; j++) {
            long long sum = 0;
            for (long p = 0; p < K; p++) {
                sum += A[i * K + p] * B[p * N + j];
            }
            C_seq[i * N + j] = sum;
        }
    }
    clock_gettime(CLOCK_MONOTONIC, &end_seq);
    double seq_time = get_time_ms(start_seq, end_seq);

    // Thread Creation
    pthread_t threads[32];
    int t_ids[32];
    bool creation_failed = false;
    int created_threads = 0;

    for (int i = 0; i < T; i++) {
        t_ids[i] = i;
        if (pthread_create(&threads[i], NULL, worker_func, &t_ids[i]) != 0) {
            creation_failed = true;
            break;
        }
        created_threads++;
    }

    // Release Gate
    pthread_mutex_lock(&gate_mutex);
    clock_gettime(CLOCK_MONOTONIC, &start_par); 
    if (creation_failed) {
        abort_flag = 1; 
    } else {
        start_flag = 1; 
    }
    pthread_cond_broadcast(&gate_cond);
    pthread_mutex_unlock(&gate_mutex);

    // Join threads
    for (int i = 0; i < created_threads; i++) {
        pthread_join(threads[i], NULL);
    }
    clock_gettime(CLOCK_MONOTONIC, &end_par); 
    double par_time = get_time_ms(start_par, end_par);

    if (creation_failed) {
        printf("Thread creation failed, aborting.\n");
        goto cleanup;
    }

    // Output and Verification
    if (M <= 10 && K <= 10 && N <= 10) { 
        print_matrix("A", A, M, K);
        print_matrix("B", B, K, N);
        print_matrix("BT", BT, N, K);
        print_matrix("C_parallel", C_par, M, N);
    } else {
        printf("A: %ldx%ld\nB: %ldx%ld\nC: %ldx%ld\n", M, K, K, N, M, N); //
    }
    printf("Workers: %ld\n", T); 

    int total_rows = 0;
    for (int i = 0; i < T; i++) {
        printf("Thread %d computed %d row%s.\n", i, worker_counts[i], worker_counts[i] == 1 ? "" : "s"); //
        total_rows += worker_counts[i];
    }

    long long checksum = 0;
    long mismatches = 0;
    for (long i = 0; i < M * N; i++) {
        checksum += C_par[i]; //
        if (C_par[i] != C_seq[i]) {
            printf("Mismatch at index %ld: Par=%lld, Seq=%lld\n", i, C_par[i], C_seq[i]); //
            mismatches++;
        }
    }

    printf("Sequential time: %.3f ms\n", seq_time); 
    printf("Parallel time  : %.3f ms\n", par_time); 
    printf("Speedup        : %.3f\n", seq_time / par_time); 
    printf("Result checksum: %lld\n", checksum); 
    printf("Mismatched elements: %ld\n", mismatches); 

    bool passed = (created_threads == T && total_rows == M && mismatches == 0); 
    printf("Result verification: %s\n", passed ? "PASSED" : "FAILED"); 

cleanup:
    free(A); free(B); free(BT); free(C_par); free(C_seq); free(worker_counts); 
    pthread_barrier_destroy(&phase_barrier); //
    
    return passed ? EXIT_SUCCESS : EXIT_FAILURE;
}